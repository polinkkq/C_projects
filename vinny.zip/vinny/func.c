#include <stdio.h>
#include <locale.h>
#include <string.h>
#include "func.h"
#include "info.h"


//вывод меню
void show_menu(){
	printf(
		"0. Выход\n"
		"1. О программе\n"
		"2. Загрузка из файла\n"
		"3. Печать списка\n"
		"4. Выполнение запроса\n");
}

//чтение из файла
int load_file(char *filename, Info info[], int limit){
	FILE * fin = fopen(filename, "r");
	
	int count = 0;
	
	//читаем из файла и сразу записываем
	while(count < limit && fscanf(fin, "%d.%d.%d %s %s %s %s", 
		&info[count].date.day, 
		&info[count].date.month, 
		&info[count].date.year,
		info[count].client, 
		info[count].name, 
		info[count].manufacturer, 
		info[count].category) == 7)
	{
		count = count + 1;
	}
	fclose(fin);
	return count;
}

void info_to_s(char *s, Info info){
	char format[] = "%d.%d.%d %s %s %s %s";
	sprintf(s, format, 
		info.date.day, info.date.month, info.date.year, 
		info.client, 
		info.name, 
		info.manufacturer, 
		info.category);
}

void echo_print(Info info[], int limit){
	for (int i = 0; i < limit; ++i){
		char s[100] = "";
		info_to_s(s, info[i]);
		puts(s);
	}
}

void do_query(Info info[], int limit, char *filename){
	FILE * fout = fopen(filename, "w");

	sort(info, limit);
	
	for (int i = 0; i < limit; ++i){
		if (strcmp(info[i].category, "Сложный") == 0){
			fprintf(fout, "%d.%d.%d %s %s %s\n", 
				info[i].date.day,
				info[i].date.month,
				info[i].date.year,
				info[i].name,
				info[i].manufacturer,
				info[i].category);
			}
	}
	
	fclose(fout);
}

void sort(Info info[], int limit){
	for (int i = 0; i < limit - 1; ++i){
		int imin = i;
		for (int j = i + 1; j < limit; ++j){
			if (lt_manufact(info[j], info[imin])) imin = j;
			if (i != imin) swap(&info[i], &info[imin]);
		}
	}
}

int lt_manufact(Info a, Info b){
	return strcmp(a.manufacturer, b.manufacturer) < 0;
}

void swap(Info *a, Info *b){
	Info temp = *a;
	*a = *b;
	*b = temp;
}

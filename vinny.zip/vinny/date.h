#ifndef DATE_H
#define DATE_H

typedef struct _date{
	int day;
	int month;
	int year;
} Date;

#endif

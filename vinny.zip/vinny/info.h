#ifndef SALE_H 
#define SALE_H

#include "date.h"

typedef struct _info {
	Date date;
	char client[40];
	char name[20];
	char manufacturer[20];
	char category[20];
} Info;

#endif

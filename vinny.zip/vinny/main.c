/**
  11.В базе данных хранятся сведения о произведенных ремонтах бытовой техники.:
  - дата обращения,
  - клиент,
  - название,
  - производитель
  - категория

  Структура входного файла in.txt
  15.05.2014	Сидоров	Телевизор	LG	Сложный
  15.06.2014	Николаева	Принтер	HP	Средний
  16.06.2014	Андреенко	Телевизор	Samsung	Сложный
  ...

  Сформировать список сложных ремонтов, упорядочив по производителям
  Структура выходного файла out.txt
  15.05.2014	Телевизор	LG	Сложный
  16.06.2014	Телевизор	Samsung	Сложный
 */

/** Задание Гусятинер Л.Б., КМПО, 2022 */
/** Кулыгина П.А., КМПО, 19.06.2024 */

/** Этап 1 из 5. Чтение из файла в массив и эхо-печать */
/** Этап 2 из 5. Выполнение заданий. Функции */
/** Этап 3 из 5. Меню */
/** Этап 4 из 5. Разбивка проекта на модули */

#include <stdio.h>
#include <locale.h>
#include <windows.h>
#include "info.h"
#include "func.h"

#define ARR_LEN 1000

int main() {
	SetConsoleOutputCP(CP_UTF8);  // переключаем консоль на UTF-8
	setlocale(LC_ALL, "ru_RU.UTF-8");  // настраиваем локаль

	int count = 0; //кол-во элементов в массиве
	Info info[ARR_LEN];

	while (1) {
		int item = -1;
		show_menu();
		scanf("%d", &item);
		if (item == 0) {
			printf("Спасибо за использование\n");
			getchar();
			getchar();
			break;
		}
		else if (item == 1){
			printf("Студент: Кулыгина Полина Александровна 313ИС-22\n");
			printf("Вариант 11\n");
			getchar();
		}
		else if (item == 2){
			count = load_file("in.txt", info, ARR_LEN);
			printf("Файл успешно загружен\n");
			getchar();
		}
		else if (item == 3){
			echo_print(info, count);
			getchar();
		}
		else if (item == 4){
				do_query(info, count, "out.txt");
				printf("Файл успешно сохранён в out.txt\n");
				getchar();
		}
		else {
			printf("Ошибка. Неверно введён номер варианта\n");
			getchar();
		}
	}
	return 0;
}

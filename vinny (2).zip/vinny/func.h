#ifndef FUNC_H
#define FUNC_H
#include "info.h"

void show_menu();
int load_file(char *fname, Info info[], int limit);
void info_to_s(char *s, Info info);
void echo_print(Info info[], int limit);
void do_query(Info info[], int limit, char* filename);
int lt_manufact(Info a, Info b);
void swap(Info *a, Info *b);
void sort(Info info[], int limit);
#endif


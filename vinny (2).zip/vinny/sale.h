#ifndef SALE_H 
#define SALE_H

#include "date.h"

typedef struct _sale {
	Date date;
	char client[40];
	char name[20];
	char manufacturer[20];
	char categoty[20];
} Sale;

#endif
